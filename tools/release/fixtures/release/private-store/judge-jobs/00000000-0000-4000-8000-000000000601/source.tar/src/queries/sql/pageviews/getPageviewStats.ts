// synthetic target for local-runner tests
export function synthetic(zone: string) {
  const unit = 'day';
  return range(unit, zone);
}
